# 함수 선언: 네임 스페이스 등록 -> 실행된다 
def sum_(a,b):
    return a+b

print('aaaa')