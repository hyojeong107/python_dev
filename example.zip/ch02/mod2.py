import mod1

print(mod1.sum_(3,6))